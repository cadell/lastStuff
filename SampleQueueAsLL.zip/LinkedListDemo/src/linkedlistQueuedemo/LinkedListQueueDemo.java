/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package linkedlistQueuedemo;

/**
 *
 * @author Cristy
 */
public class LinkedListQueueDemo
{
   public static void main(String[] args)
   {
      LinkedListQueue s = new LinkedListQueue();
      s.enqueue("Tom");
      s.enqueue("Diana");
      s.dequeue();
      s.enqueue("Cristy");
      s.enqueue("Nick");
      s.enqueue("Harry");
      while (!s.empty())
      {
         System.out.println(s.dequeue());
      }
   }
}
